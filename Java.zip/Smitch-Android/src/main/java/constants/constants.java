package constants;

public class constants {

	public static String url;
	public static String Start;
	public static String Login;
	public static String Email_Verify;
	public static String Email;
	public static String Password;
	public static String Signin;

	
	
	
}
