package Basefile;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.windows.WindowsDriver;

public class Baseclass {
	
	 
    
	
  

    public static AndroidDriver<MobileElement> driver;
    
    
    
    
	public static AndroidDriver<MobileElement> getDriver() {
		return driver;
	}

   
	
	

	public static  void Browser() throws URISyntaxException, MalformedURLException, InterruptedException
    {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("automationName", "uiautomator2");
		capabilities.setCapability("platformVersion", "10");
		capabilities.setCapability("udid", "5200d7f58d7466db"); //5200d7f58d7466db
		capabilities.setCapability("deviceName","Galaxy M10");
		capabilities.setCapability("platformName","Android");
		capabilities.setCapability("app","C:/Users/Lenovo/Downloads/app-debug.apk");
	    capabilities.setCapability("appPackage", "com.mysmitch.care");
	    capabilities.setCapability("appWaitActivity","com.mysmitch.care.ui.main.onboard.useronboard.SplashActivity");
	    capabilities.setCapability("ignoreHiddenApiPolicyError" , true);
	    capabilities.setCapability("appWaitForLaunch", "false");
	   // capabilities.setCapability("appWaitDuration", 50000);
	    capabilities.setCapability("noReset","false");
	    capabilities.setCapability("fullReset","true");
	    
	    capabilities.setCapability("enablePerformanceLogging", true);
	    capabilities.setCapability("autoGrantPermissions",true);
	    capabilities.setCapability("extendedDebugging", true);
	    capabilities.setCapability("locationContextEnabled", true);
	    capabilities.setCapability("autoAcceptAlerts", true);
	    capabilities.setCapability("locationServicesAuthorized", false);
		
	    URL url = new URL("http://0.0.0.0:4723/wd/hub");
	    driver = new AndroidDriver<MobileElement>(url,capabilities);
	   System.out.println("Appium Started");
	   
	   Thread.sleep(10000);
	
		  
    }


		public static String SSAsBase64(String screenshotName) throws IOException {
			try {
				TakesScreenshot ts = (TakesScreenshot) driver ;
				String screenshot = ts.getScreenshotAs(OutputType.BASE64);

				return "data:image/gif;base64," + screenshot;
			} catch (Exception e) {
				e.printStackTrace();
				return "Screenshot_Capture_Failure!";
			}

		}

		/* SendKeys */

		public static void sendKeys(String objkey, String data) {

			try {
				WebElementCheck(objkey).sendKeys(InputData(data));

			} catch (Exception e) {

				e.printStackTrace();
				System.out.println("The data is not send");
			}

		}

		/* Is Displayed */

		public static Boolean Displayed(String objkey) {
			// Boolean verify;
			try {
				Boolean verify = WebElement(objkey).isDisplayed();
				return verify;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}

		}

		private static WebElement WebElement(String objkey) {
			// TODO Auto-generated method stub
			return null;
		}


		/* Is enabled */

		public static Boolean Enabled(String objkey) {
			// Boolean verify;
			try {
				Boolean verify = WebElementCheck(objkey).isEnabled();
				return verify;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}

		}

		private static org.openqa.selenium.WebElement WebElementCheck(String objkey) {
			// TODO Auto-generated method stub
			return null;
		}


		/* thread sleep */
		public static void sleep(int sec) throws Exception {
			Thread.sleep(sec);
		}

		public static String InputData(String Key) throws Exception {
			String Input_Path = null;
			InputStream input = new FileInputStream(Input_Path);
			Properties Inputprob = new Properties();
			Inputprob.load(input);
			String Value = Inputprob.getProperty(Key);
			return Value;
			
		}
		/* File Upload */

		public static void fileUpload(String file, String type, String Element) {

			try {
				if (type.contains("img")) {
					String fileLocation = InputData("ImagesFolderPath") + file;
					WebElementCheck(Element).sendKeys(fileLocation);

				} else if (type.contains("apk")) {
					String fileLocation = InputData("APKFolderPath") + file;
					WebElementCheck(Element).sendKeys(fileLocation);

				} else if (type.contains("doc")) {
					String fileLocation = InputData("DocFolderPath") + file;
					WebElementCheck(Element).sendKeys(fileLocation);
				} else {
					System.out.println("The file is not defined appropriately");
				}

			} catch (Exception e) {
				System.out.println("The file is not uploaded");
			}

		}

		/* Is Selected */

		public static Boolean Selected(String objkey) {
			Boolean verify;
			try {
				verify = WebElement(objkey).isSelected();
				return verify;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}

		}

		/* Click */

		public static void clickButton(String objkey) {
			try {
				WebElement(objkey).click();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		/* get attribute */
		public static String getAttribute(String objkey, String Text) {

			try {
				String value = WebElementCheck(objkey).getAttribute(Text);
				return value;

			} catch (Exception e) {

				e.printStackTrace();
				return "Empty field";
			}

		}

		/* GetText *//* GetText */

		public static String getText(String objkey) {
			String text;
			try {
				text = WebElementCheck(objkey).getText();
				return text;
			} catch (Exception e) {

				e.printStackTrace();
				return "Empty field";
			}

		}

		/* clear text */

		public static void clearText(String objkey) {
			try {
				WebElementCheck(objkey).clear();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		/*
		 * webdriver wait
		 */

//		public static void wait(String ele) {
//			WebDriverWait wait = new WebDriverWait(driver, 20);
//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(ele)));
//		}

		/* Scroll */

		public static void scroll(int a, int b) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			String ele = "window.scrollBy" + "(" + a + "," + b + ")";
			js.executeScript(ele);
		}

		public static void dropDownByValue(String objkey, String value) throws Exception {
			try {
				WebElement Element = WebElementCheck(objkey);
				Select dropDown = new Select(Element);
				dropDown.selectByValue(value);
			} catch (Exception e) {
				System.out.println("The dropDownByValue method failed");
			}
		}

		public static void dropDownByIndex(String objkey, int index) throws Exception {
			try {
				WebElement Element = WebElementCheck(objkey);
				Select dropDown = new Select(Element);
				dropDown.selectByIndex(index);
			} catch (Exception e) {
				System.out.println("The dropDownByIndex method failed");
			}
		}

		public static void dropDownByVisibleText(String objkey, String text) throws Exception {
			try {
				WebElement Element = WebElement(objkey);
				Select dropDown = new Select(Element);
				dropDown.selectByVisibleText(text);
			} catch (Exception e) {
				System.out.println("The dropDownByVisibleText method failed");
			}

		}

		public static void enterButton(String objkey) {
			try {
				WebElement(objkey).sendKeys(Keys.ENTER);
			} catch (Exception e) {
				System.out.println("The enter button is not clicked");
			}
		}

		public static String getdropdown(String objkey) throws Exception {
			WebElement Element = WebElement(objkey);
			Select dropDown = new Select(Element);
			String firstSelected = dropDown.getFirstSelectedOption().getText();
			return firstSelected;
		}

		

		

		public static void BackSpace(String objKey) {
			Actions action = new Actions(driver);
			clickButton(objKey);
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.BACK_SPACE).build().perform();
			action.sendKeys(Keys.DELETE).build().perform();
			action.sendKeys(Keys.DELETE).build().perform();
			action.sendKeys(Keys.DELETE).build().perform();
			action.sendKeys(Keys.DELETE).build().perform();
			action.sendKeys(Keys.DELETE).build().perform();
			action.sendKeys(Keys.DELETE).build().perform();
			action.sendKeys(Keys.DELETE).build().perform();

		}

		public static boolean mousehover(String objkey) {
			Actions action = new Actions(driver);
			try {
				WebElement mousehover = WebElementCheck(objkey);

				action.moveToElement(mousehover).perform();
				return true;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		}


		









		







		
		

	}

	


