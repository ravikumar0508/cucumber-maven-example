package webelements;

import Basefile.Baseclass;
import io.cucumber.java.en.*;

public class Fitness_Test {
	
	
	
	
	@Given("As a User i need to verify the Fitness Card is displayed in the Home card or not")
	public void as_a_user_i_need_to_verify_the_fitness_card_is_displayed_in_the_home_card_or_not() {
		
		Baseclass.getDriver().findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/androidx.cardview.widget.CardView/android.view.ViewGroup").isDisplayed();
		
	    
	}

	@Given("I want to Verify that the Mentioned Fitness card is clickable")
	public void i_want_to_verify_that_the_mentioned_fitness_card_is_clickable() {
		
		Baseclass.getDriver().findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/androidx.cardview.widget.CardView/android.view.ViewGroup").click();
	
	    
	}

	@When("I Click the Card i need to Verify the Mentioned Fields in figma is Present there or not")
	public void i_click_the_card_i_need_to_verify_the_mentioned_fields_in_figma_is_present_there_or_not() {
		
	    
		Baseclass.getDriver().findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.view.ViewGroup/androidx.cardview.widget.CardView[1]/android.view.ViewGroup/android.widget.ImageView").isDisplayed();
		Baseclass.getDriver().findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.view.ViewGroup/androidx.cardview.widget.CardView[1]/android.view.ViewGroup").isDisplayed();
	}

	@When("I need to click the Live tracking Field")
	public void i_need_to_click_the_live_tracking_field() {  
		
		Baseclass.getDriver().findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.view.ViewGroup/androidx.cardview.widget.CardView[2]/android.view.ViewGroup/android.widget.TextView").click();
	    
	}
	@When("I need to Validate the Elements are Present inside as mentioned as figma or not")
	public void i_need_to_validate_the_elements_are_present_inside_as_mentioned_as_figma_or_not() {
		
		Baseclass.getDriver().findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.view.ViewGroup/androidx.cardview.widget.CardView[2]/android.view.ViewGroup").isDisplayed();
	    
		Baseclass.getDriver().findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.view.ViewGroup/androidx.cardview.widget.CardView[2]/android.view.ViewGroup").click();
		
	}

	@Then("I Click Running")
	public void i_click_running() {
		
		Baseclass.getDriver().findElementById("com.mysmitch.care:id/duration").sendKeys("20");
	    
	}

	@Then("i need to validate the fields as per figma or not")
	public void i_need_to_validate_the_fields_as_per_figma_or_not() {
		
		Baseclass.getDriver().findElementById("com.mysmitch.care:id/distance").sendKeys("2");
	    
	}

	@Then("then i need to verify the mentioned fields")
	public void then_i_need_to_verify_the_mentioned_fields() {
	    
		Baseclass.getDriver().findElementById("com.mysmitch.care:id/heart_rate").sendKeys("50");
	}

	@Then("i need to click icon is present or not")
	public void i_need_to_click_icon_is_present_or_not() {
		
		Baseclass.getDriver().findElementById("com.mysmitch.care:id/addActivity").click();
	    
	}

	
	

}
