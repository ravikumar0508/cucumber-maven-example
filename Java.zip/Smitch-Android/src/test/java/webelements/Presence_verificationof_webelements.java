package webelements;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import Basefile.Baseclass;
import constants.constants;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.windows.WindowsDriver;
import io.appium.java_client.windows.WindowsElement;


public class Presence_verificationof_webelements {
	
	public static AndroidDriver<MobileElement> driver;
	   

	public static AndroidDriver<MobileElement> getDriver() {
		return driver;
	}
	
	Baseclass get = new Baseclass();
	
	
	
	

	}
	
	
	
	
