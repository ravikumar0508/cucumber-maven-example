package stepdefinitions;

public class Fitness {

}
