package stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;



import Basefile.Baseclass;
import constants.constants;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.windows.WindowsDriver;
import io.cucumber.java.Scenario;
import io.cucumber.messages.internal.com.google.common.io.Files;
import webelements.Presence_verificationof_webelements;

public class Hooks {
	
	private static  Hooks common_utilsinstance = null;
	public static AndroidDriver<MobileElement> driver;

	public Hooks() {
	}

	public static Hooks getinstance() {

		if (common_utilsinstance==null) 
			common_utilsinstance = new Hooks();
		return common_utilsinstance;

	}

	public void LoadProperties() {

		Properties properties =new Properties();

		try {
			properties.load(getClass().getResourceAsStream("/Config.properties"));

		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		constants.Start=properties.getProperty("Start");
		constants.Email=properties.getProperty("Email");
		constants.Email_Verify=properties.getProperty("Email_Verify");
		constants.Login=properties.getProperty("Login");
		constants.Password=properties.getProperty("Password");
		constants.Signin=properties.getProperty("Signin");
		
		
			

	}

	public static void initelements() {
		
		
		PageFactory.initElements(new AppiumFieldDecorator(Baseclass.getDriver(), Duration.ofSeconds(10)), driver);

		
		
		

		
		
	}

	public  void take_screenshot(Scenario scenario){

		if (scenario.isFailed())
		{

	    byte[]  screenshotFile = ((TakesScreenshot) Baseclass.getDriver()).getScreenshotAs(OutputType.BYTES);

		scenario.attach(screenshotFile,"image/png","Screenshot");
		}
	}
		
	public static Scenario message;    

	public static void takeScreenShotAfterEveryStep() {
	        byte[] screenshot = ((TakesScreenshot)Baseclass.getDriver()).getScreenshotAs(OutputType.BYTES);
	        message.attach(screenshot, "image/png","Screenshot");
	    }

	}

	

