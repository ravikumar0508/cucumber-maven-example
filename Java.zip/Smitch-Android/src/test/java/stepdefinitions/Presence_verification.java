package stepdefinitions;

import java.util.List;

import Basefile.Baseclass;
import constants.constants;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.windows.WindowsDriver;
import io.cucumber.java.en.*;
import webelements.Presence_verificationof_webelements;

public class Presence_verification {

	
	public static AndroidDriver<MobileElement> driver;
	
    
    
    
    
	public static AndroidDriver<MobileElement> getDriver() {
		return driver;
	}
	
	Baseclass get = new Baseclass();

	
	
	Presence_verificationof_webelements elements = new Presence_verificationof_webelements();
	
	
	@Given("if i am user i need to Open the Url")
	public void if_i_am_user_i_need_to_open_the_url() {
	
		
		Baseclass.getDriver();
		Baseclass.getDriver().findElementById("com.mysmitch.care:id/start_button").click();
		
	}

	@Given("I need to Check whether i landed into correct page")
	public void i_need_to_check_whether_i_landed_into_correct_page() throws Exception {
		Thread.sleep(2000);
		Baseclass.getDriver().findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/androidx.appcompat.widget.LinearLayoutCompat/android.widget.TextView[2]").click();
	    
	}

	@When("I Landed into the page i need to check the titles of the page as expected")
	public void i_landed_into_the_page_i_need_to_check_the_titles_of_the_page_as_expected() throws Exception {
		Thread.sleep(2000);
		Baseclass.getDriver().findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/androidx.appcompat.widget.LinearLayoutCompat/android.widget.FrameLayout[2]").click();
	    Thread.sleep(4000);
		//Baseclass.getDriver().findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/androidx.appcompat.widget.LinearLayoutCompat/android.widget.FrameLayout[3]/android.widget.TextView").click();
	}

	@Then("I need to verify that the Login is Passed or not")
	public void i_need_to_verify_that_the_Login_is_passed_or_not() throws Exception {
		Thread.sleep(2000);
		
		Baseclass.getDriver().findElementById("com.mysmitch.care:id/email").sendKeys("tester111@yopmail.com");;
		Baseclass.getDriver().findElementById("com.mysmitch.care:id/password").sendKeys("Tester@123");;
		Baseclass.getDriver().findElementById("com.mysmitch.care:id/button_sign_in").click();
	    
		
	}


}
