package stepdefinitions;

import io.cucumber.java.AfterStep;
import io.cucumber.java.Scenario;

public class Screenshots extends Hooks {
@AfterStep
		public void takeScreenShotForFailedScenarios(Scenario scenario) {
			take_screenshot(scenario);
		}

}
