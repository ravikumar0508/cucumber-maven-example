package runner;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import Basefile.Baseclass;
import Basefile.Mail;
import Basefile.Zip_File;
import io.appium.java_client.windows.WindowsDriver;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import net.masterthought.cucumber.presentation.PresentationMode;
import net.masterthought.cucumber.sorting.SortingMethod;
import stepdefinitions.Hooks;

@CucumberOptions(
		
		features = "src/test/resources/Features",
		glue = {"stepdefinitions"},
		monochrome = true,
		plugin = {"pretty","html:target/report.html","json:target/cucumber.json","json:target/report/cucumber.json","junit:target/cucumber.xml","rerun:target/failed_scenario.txt","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}	
		)

public class Testrunner extends AbstractTestNGCucumberTests {
	private static final String Tag = null;
	
	@BeforeSuite	
	public  void before_scenario() {
		
		if (Baseclass.getDriver() != null) {Baseclass.getDriver().resetApp();}
		
		try {
			Hooks.getinstance().LoadProperties();
			
			if (Baseclass.getDriver()==null) {
			Baseclass.Browser();
			Hooks.initelements();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	@AfterTest
	public void close_driver() throws MalformedURLException, URISyntaxException {
		
		Baseclass.getDriver().closeApp();;
		Baseclass.getDriver().quit();
		
	}
	
	
	@AfterSuite
	public  void tearDown() throws Exception 
	{
		try {
			
			File reportOutputDirectory = new File("target/report/custom-report");
			List<String> jsonFiles = new ArrayList<>();
			jsonFiles.add("target/report/cucumber.json");
			Configuration configuration = new Configuration(reportOutputDirectory, "Cucumber_project");
			configuration.setBuildNumber("v1.0");
			//configuration.addClassifications("Browser", browser);
			configuration.addClassifications("Platform", System.getProperty("os.name").toUpperCase());
			configuration.addClassifications("TAGS", Tag);
			configuration.setSortingMethod(SortingMethod.NATURAL);
			configuration.addPresentationModes(PresentationMode.EXPAND_ALL_STEPS);
			configuration.setTrendsStatsFile(new File("target/test-classes/demo-trends.json"));
			ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
			reportBuilder.generateReports();
		}catch(Exception e)
		{
			Assert.fail("Error with report code");
		}
//		Zip_File zip = new Zip_File();
//		zip.main(null);
//		Mail mail = new Mail();
//		mail.sendmailAttachment("Smitch-Android.zip","ravikumar@mysmitch.com");
//		mail.sendmailAttachment("Smitch-Android.zip","vignesh.s@mysmitch.com");
		
		
		
	}
	
}

