package runner;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import Basefile.Baseclass;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import stepdefinitions.Hooks;

@CucumberOptions(
		features ="@target/failed_scenario.txt",
		glue ={"stepdefinitions"},
		dryRun = false,
		monochrome = true,
		plugin = {"pretty","html:target/report.html","json:target/cucumber.json","json:target/report/cucumber.json","junit:target/cucumber.xml","rerun:target/failed_scenario.txt","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}
		)
		
		

public class rerunner extends AbstractTestNGCucumberTests {
	@BeforeSuite
	public void before_scenario(@Optional("Edge") String browser) {


		try {
			Hooks.getinstance().LoadProperties();
			
			//scenarioName = scenario.getName();

			if (Baseclass.getDriver()==null)
			{
				Baseclass.Browser();
				Baseclass.getDriver();
				Hooks.initelements();}


		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@AfterTest

	public void close_browser() {

		Baseclass.getDriver().close();
	}

}
